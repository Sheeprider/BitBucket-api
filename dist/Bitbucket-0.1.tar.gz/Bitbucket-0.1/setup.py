# -*- coding: utf-8 -*-
from distutils.core import setup

setup(
  name='Bitbucket',
  version='0.1',
  description='Bitbucket API',
  author='Baptiste Millou',
  author_email='baptiste@smoothie-creative.com',
  url='https://github.com/Sheeprider/Py-BitBucket',
  py_modules=['bitbucket'],
  licence='GPL',
  )
